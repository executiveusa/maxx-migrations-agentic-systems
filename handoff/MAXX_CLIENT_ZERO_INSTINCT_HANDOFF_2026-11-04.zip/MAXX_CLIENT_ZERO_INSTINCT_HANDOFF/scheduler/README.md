Templates only. Do not enable until a real authenticated Instinct runner and authorized persistent host are verified. This is NOT a working Instinct scheduler.
