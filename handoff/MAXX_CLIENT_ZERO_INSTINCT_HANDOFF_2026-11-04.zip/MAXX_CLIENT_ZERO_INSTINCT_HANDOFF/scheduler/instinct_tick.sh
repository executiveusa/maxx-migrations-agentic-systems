#!/usr/bin/env bash
set -euo pipefail
# Template: Instinct must configure a verified runner, checkpoint store and approvals.
if [ -z "$INSTINCT_RUNNER" ]; then echo "No verified Instinct runner" >&2; exit 2; fi
case "$INSTINCT_RUNNER" in /*) ;; *) echo "Runner must be absolute path" >&2; exit 2;; esac
if [ ! -x "$INSTINCT_RUNNER" ]; then echo "Runner not executable" >&2; exit 2; fi
mkdir -p "$HOME/.local/state/maxx-instinct"
exec 9>"$HOME/.local/state/maxx-instinct/tick.lock"
flock -n 9 || exit 0
exec timeout 470 "$INSTINCT_RUNNER"
