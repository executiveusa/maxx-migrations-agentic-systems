# Find this ChatGPT conversation and communicate safely
This conversation concerns MAXX SUITE / MACS Client Zero, Instinct as the intended execution owner, and ChatGPT as independent controller. User requested both parties check every ten minutes and to be removed from routine work.

Search the user's authorized ChatGPT conversation history for distinctive exact phrases:
- is the 10 min part active? not just the hour?
- no you need to have a 10 min chron as well running to check for instincts work
- what project is this ?
- MAXX SUITE MACS Client Zero PR #37

The assistant cannot read or provide this chat's unique conversation ID or URL. Do not invent one. Even if you have access to the user's ChatGPT chat list, that does not prove an API route to this exact conversation. If a chat message is actually sent, verify it appears. Do not rely on chat access for autonomous work.

Canonical durable communication is the GitHub PR #37 conversation. GitHub Issues are disabled, so the PR is the application-level A2A mailbox, not native Agent2Agent transport. Use stable structured a2a-ack/1, a2a-status/1, a2a-review/1, a2a-blocked/1, a2a-complete/1 messages, deduplicate IDs, and include task, SHA, evidence and blockers. No secrets or customer data in public comments. ChatGPT hourly automation ID 6aeb82f9ffa4819190d4e1429ee9a586 reads this mailbox. GitHub Actions cron checks it every ten minutes but DOES NOT invoke ChatGPT or Instinct models.

History: pilot PR #37 records PRD v1.0, owner decisions, task graph, acceptance matrix, manifest and one-shot Instinct prompt. Monitor PR #38 merged to develop SHA 3c39f9d28cbed8e3da7e19f4862923520db1794b. The monitor PR smoke run passed; first scheduled run was not yet verified at last check. Instinct ACK and authenticated ten-minute worker were unverified. Correct MACS staging Supabase project and Stacy's account mapping were unavailable. Existing public intake service-role write and approval binding require security work.

Scope: first client MACS Digital Media, then only after approval others. Revenue offer Vibe Audit; shared platform MAXX; bounded Mercury demo experiment remains disabled. No new control plane. Owner wants out of routine implementation, but must retain approval over production, money, permissions and consequential external actions.
