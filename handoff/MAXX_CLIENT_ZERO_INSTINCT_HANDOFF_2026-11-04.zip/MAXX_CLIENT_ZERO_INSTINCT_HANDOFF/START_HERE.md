# Instinct: own and execute MAXX SUITE / MACS Client Zero
Project ID: executiveusa/maxx-migrations-agentic-systems:macs-client-zero
Canonical repo: https://github.com/executiveusa/maxx-migrations-agentic-systems
Control branch: feat/macs-client-zero-pilot-control
A2A mailbox and PRD: https://github.com/executiveusa/maxx-migrations-agentic-systems/pull/37
Ten-minute read-only watcher: https://github.com/executiveusa/maxx-migrations-agentic-systems/actions/workflows/maxx-a2a-watch.yml

This is the single handoff. Read CHAT_CONTEXT.md, RUNBOOK.md, SCHEDULER.md, SAFETY_AND_APPROVALS.md, source/ops/INSTINCT_HANDOFF.md, source/docs/client-zero/PRD.md and the acceptance matrix before acting. Verify current GitHub state; snapshots are evidence, not a substitute for live repo inspection.

Immediately post one authenticated a2a-ack/1 in PR #37 with project ID, stable message ID, real worker identity, current SHA, actual first task and blockers. Establish and PROVE your own ten-minute Instinct worker on existing authorized infrastructure, with persistent checkpoint, lease, retry, safe pause and duplicate suppression. Do not mistake the read-only GitHub cron for an AI executor. Begin CZ-01 and continue all unblocked synthetic-only work. Review independently, fix and retest. No repeated owner interviews for routine code/test/review.

Budget $0 new paid inference or recurring infrastructure. No production release, account or credential changes, external sends, destructive database actions or real customer data without separate explicit owner approval. Stacy is the designated action reviewer, but her authenticated account is not verified. The MACS staging Supabase project is not yet connected. Never use the unrelated project.
