# Scheduling reality and next steps
Already configured: read-only GitHub Actions watcher on develop, .github/workflows/maxx-a2a-watch.yml, cron */10 * * * * UTC. It checks PR #37 and records a JSON artifact; GitHub scheduling is best effort. It does not invoke any model.
Already configured: ChatGPT Automation hourly, ID 6aeb82f9ffa4819190d4e1429ee9a586. ChatGPT native Automations cannot run model calls every ten minutes.
Not verified: Instinct authenticated worker, native scheduler, persistent checkpoint and actual ten-minute execution.

Instinct must inspect its supported runtime, configure a real ten-minute execution schedule only with existing approved zero-new-cost infrastructure, prove actual timed run, durable checkpoint, retry, duplicate suppression, crash/restart, pause and logs, then post proof to PR #37. Included systemd templates are NOT installed and do not establish a worker. If no supported runner is available, stop that branch of work and mark BLOCKED while continuing safe independent tasks.
