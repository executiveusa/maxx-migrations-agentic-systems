# Authority confirmed by owner on 2026-11-04
Allowed: inspect, synthetic-only development, isolated branches and draft PRs, tests, independent review, reversible no-cost staging preparation.
Not allowed without separate explicit owner approval: new paid infrastructure/inference (budget $0), production merges/deployments, secrets/accounts/permissions, destructive DB actions, external sends, real client data, contracts and public claims.
Use only MACS-owned Supabase staging, not an unrelated project. Stacy is the designated action reviewer but her authenticated account and membership are not verified. Builder cannot self-certify. Portal fallback must remain available. No repeat interview for already approved routine work. Escalate only a genuinely protected action or unresolvable blocker.
