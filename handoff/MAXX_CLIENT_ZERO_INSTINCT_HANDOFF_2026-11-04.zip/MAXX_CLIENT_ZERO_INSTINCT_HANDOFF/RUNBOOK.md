# Execute without routine owner intervention
1. Verify repo, develop and pilot branch SHA, PR #37 comments, active CI, actual GitHub cron runs and Instinct environment. Do not reset or overwrite changes.
2. Read complete current PRD, decisions, acceptance matrix, execution graph, manifest, federation contract, rollback and existing intake API / approval SQL. Source snapshots in this ZIP are for cold-start inspection.
3. Post authenticated a2a-ack/1 to PR #37; do not fabricate access. Create durable task checkpoint and inbound message cursor in an existing approved persistent store. Deduplicate message IDs and task effects.
4. Inspect native Instinct scheduler first. If supported, schedule an actual worker every ten minutes on existing authorized host; prove real timed execution, lease, checkpoint, crash/restart, safe pause and idempotency. If unavailable, mark blocked, do not invent a provider endpoint or credentials.
5. Work CZ-01 onward from source/ops/EXECUTION_GRAPH.yaml. Continue unblocked code and synthetic tests while staging is blocked. Use isolated branches, existing checks, independent security reviewer and reversible changes.
6. Fix bounded intake, abuse protection, atomic writes and idempotency; tenant isolation; immutable exact-payload approval; exactly-once note; export, evidence and rollback. Run two-tenant and concurrency tests on correct MACS-owned staging only.
7. Report only meaningful changes in PR #37 with stable structured IDs, exact SHA, CI links, evidence and protected blockers. No circular status messages.
8. Separate owner approval is mandatory before production release, spending, secrets/account/permission changes, destructive migrations, real client data, consequential external sends, public claims or contracts.
9. Final acceptance requires A01-A15 as applicable, independent review, live staging proof, rollback rehearsal and exact production verification after release authorization. No success claim from code or a preview badge alone.
